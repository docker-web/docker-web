<h1 align="center">
  <picture>
    <img align="center" alt="transmission" src="./logo.svg" height="100">
  </picture>
  transmission
</h1>

- image version: linuxserver/transmission
- [x] Accessible over http ?
- [ ] Accessible over https ?
- [ ] ARM 64 compatible ?

# peers

For sourcing torrents:
 1. edit preferences
 2. go to network tab
 3. set 7815 for "Peer listening port"
 