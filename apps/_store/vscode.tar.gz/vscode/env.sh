#!/bin/bash
export APP_NAME="vscode"
export DOMAIN="${APP_NAME}.${MAIN_DOMAIN}"
export DOMAIN_NUXT="nuxt.${MAIN_DOMAIN}"
export PORT="7713"
export PORT_EXPOSED="3000"
export CONNECTION_TOKEN="connectiontoken"
