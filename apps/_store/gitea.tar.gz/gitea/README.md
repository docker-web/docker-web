<h1 align="center">
  <picture>
    <img align="center" alt="gitea" src="./logo.svg" height="40">
  </picture>
  Gitea
</h1>
