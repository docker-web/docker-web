export DOMAIN="$MAIN_DOMAIN"
export PORT="7700"
export PORT_EXPOSED="80"
export REDIRECTIONS=""
export POST_INSTALL_TEST_CMD="pwd"
export LAUNCHER_HIDDEN=true
export ALIASES="tv->tv.$MAIN_DOMAIN map->mappy.com youtube->www.youtube.com chatgpt->chatgpt.com whatsapp->web.whatsapp.com"
