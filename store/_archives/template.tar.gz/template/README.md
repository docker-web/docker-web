<h1 align="center">
  <picture>
    <img align="center" alt="app-name" src="./logo.svg" height="100">
  </picture>
  app-name
</h1>
