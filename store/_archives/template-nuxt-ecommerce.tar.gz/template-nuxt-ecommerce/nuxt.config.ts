export default defineNuxtConfig({
  modules: ['@pinia/nuxt', '@nuxtjs/tailwindcss'],
  css: ['@/assets/tailwind.css'],
  runtimeConfig: {
    stripeSecretKey: process.env.STRIPE_SECRET_KEY || '',
    public: {
      stripePublicKey: process.env.STRIPE_PUBLIC_KEY || ''
    }
  },
  app: {
    head: { title: 'Nuxt E-commerce Template' }
  }
})
