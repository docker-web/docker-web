export PORT="7710"
export PORT_EXPOSED="3000"
export DOMAIN="shop.example.com"
export PUID="1000"
export PGID="1000"
# Stripe keys (test mode recommended)
export STRIPE_PUBLIC_KEY="pk_test_xxx"
export STRIPE_SECRET_KEY="sk_test_xxx"
