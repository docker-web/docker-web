# Nuxt E-commerce Template

Storefront Nuxt 4 minimal pour docker-web: catalogue, fiche produit, panier, checkout Stripe.

## Configuration

Variables (voir `config.sh`):
- PORT / PORT_EXPOSED
- DOMAIN
- PUID / PGID
- STRIPE_PUBLIC_KEY / STRIPE_SECRET_KEY

## Démarrage

1. Ajuster `config.sh`.
2. Construire et lancer via `docker-compose.yml`.
3. Accéder au domaine configuré (reverse proxy requis via réseau `dockerweb`).

## Développement

- Dépendances: PNPM 10.x
- Commandes: `pnpm dev`, `pnpm build`, `pnpm preview`

