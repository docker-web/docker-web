import { defineStore } from 'pinia'

export interface CartItem {
  id: string
  name: string
  price: number
  image?: string
  qty: number
}

export const useCartStore = defineStore('cart', {
  state: () => ({
    items: [] as CartItem[]
  }),
  getters: {
    count: (s) => s.items.reduce((a, i) => a + i.qty, 0),
    total: (s) => s.items.reduce((a, i) => a + i.price * i.qty, 0)
  },
  actions: {
    add(item: Omit<CartItem, 'qty'>, qty = 1) {
      const existing = this.items.find((i) => i.id === item.id)
      if (existing) existing.qty += qty
      else this.items.push({ ...item, qty })
      this.persist()
    },
    remove(id: string) {
      this.items = this.items.filter((i) => i.id !== id)
      this.persist()
    },
    setQty(id: string, qty: number) {
      const it = this.items.find((i) => i.id === id)
      if (!it) return
      it.qty = Math.max(1, qty)
      this.persist()
    },
    clear() {
      this.items = []
      this.persist()
    },
    persist() {
      if (process.client) localStorage.setItem('cart', JSON.stringify(this.items))
    },
    hydrate() {
      if (process.client) {
        const raw = localStorage.getItem('cart')
        if (raw) this.items = JSON.parse(raw)
      }
    }
  }
})
