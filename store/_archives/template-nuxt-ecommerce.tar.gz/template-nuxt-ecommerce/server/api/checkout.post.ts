import Stripe from 'stripe'
import products from '@/data/products.json'

export default defineEventHandler(async (event) => {
  const config = useRuntimeConfig()
  const body = await readBody<{ items: { id: string; qty: number }[] }>(event)
  const secret = config.stripeSecretKey
  if (!secret) {
    throw createError({ statusCode: 500, statusMessage: 'Stripe secret key missing' })
  }
  if (!body?.items?.length) {
    throw createError({ statusCode: 400, statusMessage: 'No items' })
  }

  const stripe = new Stripe(secret, { apiVersion: '2024-06-20' })

  const lookup = new Map(products.map((p: any) => [p.id, p]))
  const lineItems = body.items
    .map(({ id, qty }) => {
      const p = lookup.get(id)
      if (!p || !p.stripePriceId) return null
      return {
        price: p.stripePriceId as string,
        quantity: Math.max(1, qty)
      }
    })
    .filter(Boolean) as Stripe.Checkout.SessionCreateParams.LineItem[]

  if (!lineItems.length) {
    throw createError({ statusCode: 400, statusMessage: 'Invalid items' })
  }

  const origin = getHeader(event, 'origin') || `http://${getHeader(event, 'host')}`

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: lineItems,
    success_url: `${origin}/success`,
    cancel_url: `${origin}/cancel`
  })

  return { id: session.id, url: session.url }
})
