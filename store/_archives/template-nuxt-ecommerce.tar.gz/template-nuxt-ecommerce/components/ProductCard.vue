<template>
  <div class="border rounded-lg overflow-hidden flex flex-col">
    <img :src="product.image" :alt="product.name" class="w-full h-48 object-cover" />
    <div class="p-4 flex-1 flex flex-col">
      <h3 class="font-semibold mb-1">{{ product.name }}</h3>
      <p class="text-sm text-gray-600 mb-3 line-clamp-2">{{ product.description }}</p>
      <div class="mt-auto flex items-center justify-between">
        <span class="font-semibold">{{ (product.price / 100).toFixed(2) }} €</span>
        <div class="space-x-2">
          <NuxtLink :to="`/product/${product.slug}`" class="text-sky-700">Détails</NuxtLink>
          <button @click="addToCart" class="bg-sky-600 text-white px-3 py-1 rounded">Ajouter</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useCartStore } from '@/stores/cart'
const props = defineProps<{ product: any }>()
const cart = useCartStore()
const addToCart = () => {
  cart.add({ id: props.product.id, name: props.product.name, price: props.product.price, image: props.product.image }, 1)
}
</script>
