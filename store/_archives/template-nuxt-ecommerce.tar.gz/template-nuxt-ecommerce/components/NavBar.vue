<template>
  <nav class="bg-sky-600 text-white">
    <div class="container mx-auto p-4 flex items-center justify-between">
      <NuxtLink to="/" class="font-semibold">E-Shop</NuxtLink>
      <NuxtLink to="/cart" class="relative">
        Panier
        <span v-if="count" class="ml-2 bg-white text-sky-700 rounded px-2 py-0.5 text-sm">{{ count }}</span>
      </NuxtLink>
    </div>
  </nav>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { useCartStore } from '@/stores/cart'
const cart = useCartStore()
const { count } = storeToRefs(cart)
if (process.client) cart.hydrate()
</script>
