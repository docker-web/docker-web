<template>
  <div v-if="product">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <img :src="product.image" :alt="product.name" class="w-full rounded-lg" />
      <div>
        <h1 class="text-2xl font-semibold mb-2">{{ product.name }}</h1>
        <p class="text-gray-700 mb-4">{{ product.description }}</p>
        <div class="flex items-center justify-between mb-6">
          <span class="text-xl font-bold">{{ (product.price / 100).toFixed(2) }} €</span>
          <div class="space-x-2">
            <button @click="qty = Math.max(1, qty-1)" class="px-3 py-1 border rounded">-</button>
            <span>{{ qty }}</span>
            <button @click="qty++" class="px-3 py-1 border rounded">+</button>
          </div>
        </div>
        <button @click="addToCart" class="bg-sky-600 text-white px-4 py-2 rounded">Ajouter au panier</button>
      </div>
    </div>
  </div>
  <div v-else>
    <p>Produit introuvable.</p>
  </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
import products from '@/data/products.json'
import { useCartStore } from '@/stores/cart'
import { ref } from 'vue'
const route = useRoute()
const slug = route.params.slug as string
const product = products.find((p) => p.slug === slug)
const cart = useCartStore()
const qty = ref(1)
const addToCart = () => {
  if (!product) return
  cart.add({ id: product.id, name: product.name, price: product.price, image: product.image }, qty.value)
}
</script>
