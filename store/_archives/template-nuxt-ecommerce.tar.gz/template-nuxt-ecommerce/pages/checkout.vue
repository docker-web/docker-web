<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">Checkout</h1>
    <div class="space-y-2 mb-4">
      <div v-for="it in items" :key="it.id" class="flex items-center justify-between">
        <span>{{ it.name }} × {{ it.qty }}</span>
        <span>{{ ((it.price * it.qty)/100).toFixed(2) }} €</span>
      </div>
      <div class="font-semibold">Total: {{ (total/100).toFixed(2) }} €</div>
    </div>
    <button @click="pay" class="bg-sky-600 text-white px-4 py-2 rounded" :disabled="!items.length || loading">
      {{ loading ? 'Redirection...' : 'Payer avec Stripe' }}
    </button>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { useCartStore } from '@/stores/cart'
import { ref } from 'vue'
const cart = useCartStore()
if (process.client) cart.hydrate()
const { items, total } = storeToRefs(cart)
const loading = ref(false)

const pay = async () => {
  loading.value = true
  try {
    const res = await $fetch('/api/checkout', {
      method: 'POST',
      body: { items: items.value.map(({ id, qty }) => ({ id, qty })) }
    }) as any
    if (res?.url) window.location.href = res.url
  } finally {
    loading.value = false
  }
}
</script>
