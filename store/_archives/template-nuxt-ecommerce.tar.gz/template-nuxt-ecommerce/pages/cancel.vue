<template>
  <div>
    <h1 class="text-2xl font-bold mb-2">Paiement annulé</h1>
    <p>Vous pouvez reprendre vos achats.</p>
  </div>
</template>
