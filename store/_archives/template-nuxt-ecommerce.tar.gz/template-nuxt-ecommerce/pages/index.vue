<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">Catalogue</h1>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      <ProductCard v-for="p in products" :key="p.id" :product="p" />
    </div>
  </div>
</template>

<script setup lang="ts">
import products from '@/data/products.json'
</script>

<script lang="ts">
export default {
  data() {
    return { products }
  }
}
</script>
