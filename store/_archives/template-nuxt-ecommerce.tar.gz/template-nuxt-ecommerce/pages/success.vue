<template>
  <div>
    <h1 class="text-2xl font-bold mb-2">Merci pour votre commande !</h1>
    <p>Vous recevrez un email de confirmation sous peu.</p>
  </div>
</template>
