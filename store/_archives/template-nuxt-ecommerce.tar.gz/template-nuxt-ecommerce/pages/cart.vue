<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">Panier</h1>
    <div v-if="items.length; else empty">
      <div v-for="it in items" :key="it.id" class="flex items-center justify-between border-b py-3">
        <div class="flex items-center gap-3">
          <img v-if="it.image" :src="it.image" class="w-16 h-16 object-cover rounded" />
          <div>
            <div class="font-semibold">{{ it.name }}</div>
            <div class="text-sm text-gray-600">{{ (it.price / 100).toFixed(2) }} €</div>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <button @click="setQty(it.id, it.qty-1)" class="px-3 py-1 border rounded">-</button>
          <span>{{ it.qty }}</span>
          <button @click="setQty(it.id, it.qty+1)" class="px-3 py-1 border rounded">+</button>
          <button @click="remove(it.id)" class="px-3 py-1 border rounded text-red-600">Supprimer</button>
        </div>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-xl font-semibold">Total: {{ (total / 100).toFixed(2) }} €</div>
        <NuxtLink to="/checkout" class="bg-sky-600 text-white px-4 py-2 rounded">Checkout</NuxtLink>
      </div>
    </div>
    <template #empty>
      <p>Votre panier est vide.</p>
    </template>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { useCartStore } from '@/stores/cart'
const cart = useCartStore()
if (process.client) cart.hydrate()
const { items, total } = storeToRefs(cart)
const remove = (id: string) => cart.remove(id)
const setQty = (id: string, qty: number) => cart.setQty(id, qty)
</script>
