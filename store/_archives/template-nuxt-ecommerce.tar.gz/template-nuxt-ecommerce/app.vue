<template>
  <div>
    <NavBar />
    <div class="container mx-auto p-4">
      <NuxtPage />
    </div>
  </div>
</template>

<script setup lang="ts">
</script>
