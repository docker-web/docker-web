<h1 align="center">
  <picture>
    <img align="center" alt="docker-web" src="../../docs/docker-web.svg" height="40">
  </picture>
  Launcher
</h1>
