<h1 align="center">
  <picture>
    <img align="center" alt="APP-NAME" src="./logo.svg" height="100">
  </picture>
  APP-NAME
</h1>
