export DOMAIN="nicotine.$MAIN_DOMAIN"
export PORT="7708"
export PORT_EXPOSED="6565"
