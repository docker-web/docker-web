<template>
  <NuxtTemplate />
</template>
