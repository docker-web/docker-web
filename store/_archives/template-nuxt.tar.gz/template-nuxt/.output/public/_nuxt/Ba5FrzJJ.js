import{_ as t,I as o,g as n,y as c}from"./CF4zNo1g.js";const r={};function s(a,_){const e=n("NuxtTemplatee");return c(),o(e)}const m=t(r,[["render",s]]);export{m as default};
