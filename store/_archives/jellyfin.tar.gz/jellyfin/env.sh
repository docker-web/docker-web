export DOMAIN="jellyfin.$MAIN_DOMAIN"
export PORT="7702"
export PORT_EXPOSED="8096"
