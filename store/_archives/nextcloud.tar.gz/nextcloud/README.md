<h1 align="center">
  <picture>
    <img align="center" alt="nextcloud" src="./logo.svg" height="40">
  </picture>
  Nextcloud
</h1>
